This folder contains the NanoPlots report for the raw read data downloaded from the NCBI Sequence Read Archive using
the SRA Toolkit.
There were 13.9 Gbases in total.

The command used to do so was:
> fasterq-dump SRR25038556
Where SRR2503855 is the run accession number. The final fastq file size was 27 Gigabytes.  

Please download the "NanoPlot_Results_ICA_genome.zip" zip file to view the NanoPlots results. 

Make sure to click on the "NanoPlot-report.html" file inside the zip file to see all the results conveniently.
